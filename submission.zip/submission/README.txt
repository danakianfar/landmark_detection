Project AI - June 2017
CNN-based Eye Landmark Estimation

Please find our code under code/
The report can be found in report.pdf
For the dataset, please contact us.
Our best trained model can be found under code/model/bw/

Students: 
Dana Kianfar - 11391014 - dana.kianfar@gmail.com
Jose Gallego Posada - 11390689 - jgalle29@gmail.com